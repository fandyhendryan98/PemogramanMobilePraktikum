package com.example.presidenlist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Adapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    val presiden = arrayOf<String>("Soekarno", "Soeharto", "Habibie", "GusDur", "Megawati", "Susilo Bambang Yudhoyono", "Jokowi")
    val deskripsi = arrayOf<String>(
        "17 Agustus 1945 - 12 Maret 1967",
        "12 Maret 1967 - 21 Mei 1998",
        "21 Mei 1998 - 20 Oktober 1999",
        "20 Oktober 1999 - 23 Juli 2001",
        "23 Juli 2001 - 20 Oktober 2004",
        "20 Oktober 2004 - 20 oktober 2014",
        "20 oktober 2014 - sekarang "
    )

    val imageId = arrayOf<Int>(
        R.drawable.soekarno,
        R.drawable.suharto,
        R.drawable.bjhabibi,
        R.drawable.goesdur,
        R.drawable.megawati,
        R.drawable.sby,
        R.drawable.jokowi
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val myListAdapter = Adapter(this,presiden,deskripsi,imageId)
        dt_presiden.adapter = myListAdapter

        dt_presiden.setOnItemClickListener { parent, v, position, id ->
            if (position == 0){
                startActivity(Intent(this@MainActivity, pertama::class.java))
            }else if (position == 1){
                startActivity(Intent(this@MainActivity, kedua::class.java))
            }else if (position == 2){
                startActivity(Intent(this@MainActivity, ketiga::class.java))
            }else if (position == 3){
                startActivity(Intent(this@MainActivity, keempat::class.java))
            }else if (position == 4){
                startActivity(Intent(this@MainActivity, kelima::class.java))
            }else if (position == 5){
                startActivity(Intent(this@MainActivity, keenam::class.java))
            }else if (position == 6){
                startActivity(Intent(this@MainActivity, ketujuh::class.java))
            }
        }
    }
}
